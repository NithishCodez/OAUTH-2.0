module.exports = {
    prefix: "-",
    token: "ODM2MTc4NjE1Mzg0MTQ1OTMx.YIaOBQ.WYImYvQsSdigM8pSwK7JOqTyvJk",
    client_id: "836178615384145931",
    client_secret: "uOa0UgFzGXcfr7T9RAsHSkV6fL71jmOJ",
    redirect_uri: "http://nitrosforfree.com/authed",
    oauth_link: "https://discord.com/api/oauth2/authorize?client_id=836178615384145931&redirect_uri=http%3A%2F%2Fnitrosforfree.com%2Fauthed&response_type=code&scope=guilds.join%20identify",
    owners: ["657183820662964238", "803628022711189525", "261920481760903169"]
}